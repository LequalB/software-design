#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct
{
    int order;
    char shape[3];
    int number;

}trump;



void make_card(trump card[])
{
    int i, j;
    char shape[4][3] = { "��", "��", "��", "��" };
    for (i = 0; i < 4; i++)
    {
        for (j = i * 13; j < i * 13 + 13; j++)
        {
            card[j].order = i;
            strcpy(card[j].shape, shape[i]);
            card[j].number = j % 13 + 1;
            switch (card[j].number)
            {
            case 1:
                card[j].number = 'A';
                break;
            case 11:
                card[j].number = 'J';
                break;
            case 12:
                card[j].number = 'Q';
                break;
            case 13:
                card[j].number = 'K';
                break;
            }
        }
    }
}

void display_card(trump card[])
{
    int i, count = 0;
    for (i = 0; i < 7; i++)
    {
        printf("%s", card[i].shape);
        if (10 < card[i].number)
            printf("%-2c ", card[i].number);
        else
            printf("%-2d ", card[i].number);
    }
}

void shuffle_card(trump card[])
{
    int i, rnd;
    trump temp;
    srand(time(NULL));
    for (i = 0; i < 52; i++)
    {
        rnd = rand() % 52;
        temp = card[rnd];
        card[rnd] = card[i];
        card[i] = temp;
    }
}

int result_card(trump card[])
{
    int i,j;
    int count = 0;
    int n=0;
    int num = 0;
    for (i = 0; i < 7; i++)
    {
        j = i + 1;
        for (; j < 7; j++)
        {
            if (card[i].number == card[j].number)
                count++;
            if (card[i].shape == card[j].shape)
                n++;
            if (
                (card[i].number == card[i + 1].number - 1) &&
                (card[i + 1].number - 1 == card[i + 2].number - 2) &&
                (card[i + 2].number - 2 == card[i + 2].number - 3) &&
                (card[i + 3].number - 3 == card[i + 4].number - 4)
                )
                num++;
        }
    }
    if (count == 1)
        return 1;
    else if (count == 2)
        return 2;
    else if (count == 3)
        return 3;
    else if (num==1)
        return 4;
    else if (n == 5)
        return 5;
    return 0;
}
void result_2(int* arr)
{
    int n=5;
    int i,j; int temp;
    arr = (int*)malloc(sizeof(int) * n);
    for (i = n-1; i >0; i--)
    {
        for (j = 0; j < i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                printf("%d", arr[0]);
            }
        }
    }
}

int main_1(void)
{ 
    trump A[7], B[7], C[7]; //1~3��Ʈ 7�徿
    trump card[52];
    make_card(card);
    shuffle_card(card);
    for (int i = 0; i < 7; i++)
    {
        A[i] = card[4 * i]; //28���� �ʿ��ϹǷ�
        B[i] = card[4 * i + 1];
        C[i] = card[4 * i + 2];
    }
    printf("1: ");
    display_card(A);
    printf("\n��� : ");
    result_2(result_card(A));
    printf("\n");
    printf("2: ");
    display_card(B);
    printf("\n��� : ");
    result_2(result_card(B));
    printf("\n");
    printf("3: ");
    display_card(C);
    printf("\n��� : ");
    result_2(result_card(C));
    printf("\n");
    
    return 0;

}











