#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main()
{
	char ch;
	char line[200];
	char line_c;
	int i;
	int num;
	printf("ã�� ����(character) �Է� : ");
	scanf("%c",&ch);

	FILE* fp;
	fp = fopen("week8-1.txt", "r");
	
	while (!feof(fp))
	{
		fgets(line, 100, fp);
		printf("%s", line);
		for (i = 0; i < strlen(line); i++)
		{

			line_c = line[i];
			if (line_c == '&ch');
			num++;


		}


	}
	printf("%c���ڴ� %d�� �ֽ��ϴ�.\n",ch, num);
	printf("���α׷� ����\n");

	fclose(fp);

}