#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void init(int* arr1[10], int* arr2[10]);
void evaluate_arr(int* arr1[10], int* arr2[10], double* arr3[10], int arr4[10]);
void printResult(double* arr[10]);

int main() {
	int arr1[10], arr2[10];
	double resArr[10];//�迭 �ʱ�ȭ
	srand(time(NULL));
	for (int i = 0; i < 10; i++)
	{
		arr1[i] = rand() % 100;
		arr2[i] = rand() % 100;
	}//2���� �迭 �������� �� ����(0~100)
	init(arr1, arr2);//�� ����
	evaluate_arr();
	printf("1�� �� ���\n");
	printResult();
	evaluate_arr();
	printf("2�� �� ���\n");
	printResult(resArr);
}

void init(int* ptr1, int* ptr2) {
	double ptr3[10];
	for (int j = 0; j < 10; j++)
	{
		if (ptr1[j] > ptr2[j])
			ptr3[j] = ptr1[j];
		else
			ptr3[j] = ptr2[j];
	}

}

void evaluate_arr(int* ptr, int* ptr2, double* ptr3, int n) {
	for (n = 0; n < 10; n++)
	{
		if (ptr[n] >= ptr2[n])
		{
			ptr3[n] = ptr[n] * 0.6 + ptr2[n] * 0.4;
		}
		else
		{
			ptr3[n] = ptr2[n] * 0.6 + ptr[n] * 0.4;
		}
		printf("0.1f", ptr3[n]);
	}
}
void printResult(double* ptr)
{

	printf("%0.1f", ptr);

}




