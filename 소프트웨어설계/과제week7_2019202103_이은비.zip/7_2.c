#include <stdio.h>
#define MAX_SIZE 2

typedef struct {
	int front;
	int rear;
	int data[];

}Queuetype;

void init_queue(Queuetype* q) {
	q->rear = -1;
	q->front = -1;
}

int is_full(Queuetype* q) {
	if (q->rear == MAX_SIZE - 1)
		return 1;
	else return 0;
}

int is_empty(Queuetype* q) {
	if (q->rear == q->front)return 1;
	else return 0;
}

void enqueue(Queuetype* q, int item) {
	if (is_full(q)) {
		printf("ť�� ��á��\n");
		return 0;
	}
	q->data[++(q->rear)] = item;
}

int dequeue(Queuetype* q) {
	if (is_empty(q)) {
		printf("ť�� �����.\n");
		return -1;
	}
	int item = q->data[++(q->front)];
	return item;
}
void queue_print(Queuetype* q) {
	for (int i = 0; i<MAX_SIZE; i++)
	{
		if (i <= q->front || i > q->rear)
		{
			printf("���簪 3c");
		}
		else
		{
			printf("%d", q->data[i]);
		}
		printf("\n");
	}

}




int main()
{
	int item = 0; int a;
	Queuetype q;
	printf("ť�� ũ��: 2\n");
	printf("enqueue ����, 1 ����\n");
	enqueue(&q, 1); queue_print(&q);
	enqueue(&q, 2); queue_print(&q);
	
	item = dequeue(&q); queue_print(&q);
	item = dequeue(&q); queue_print(&q);

	return 0;
}
